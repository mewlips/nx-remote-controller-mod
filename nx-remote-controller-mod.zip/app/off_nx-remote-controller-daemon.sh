#!/bin/bash

killall nx-remote-controller-daemon.sh
killall nx-remote-controller-daemon

exit 0
