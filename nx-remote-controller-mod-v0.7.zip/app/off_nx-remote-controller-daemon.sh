#!/bin/bash

killall nx-input-injector
killall xev-nx
killall nx-remote-controller-daemon

exit 0
